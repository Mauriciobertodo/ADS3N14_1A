package com.senac.apps.views;

public class ConsoleView {

	public void imprimeInteiro(Integer valor) {
		System.out.println(valor);
	}

}
