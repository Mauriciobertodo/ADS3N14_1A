package com.senac.mvc.view;

abstract public class ContatoView {
	abstract public void printContato(String nome, String telefone);
}
